package geneticalgorithm.classes;

import geneticalgorithm.fitnesses.CountOnes;
import geneticalgorithm.fitnesses.Evaluable;
import geneticalgorithm.fitnesses.Fitness4;
import geneticalgorithm.fitnesses.FitnessComparator;
import geneticalgorithm.fitnesses.Mystery;
import geneticalgorithm.lists.EvaluableList;

public class GATest {
    boolean DEBUG = false;

    boolean headlessChicken = true;

    Population pop;
    EvaluableList allInd, matingPool, nextGen;

    String function = "countOnes";

    int matingPoolPercent = 20;
    int mutation;
    int evaluations;
    int crossovers = 1;
    int maxEvaluations = 1000000;

    public GATest() {
        pop = new Population();
        allInd = pop.getPopulation();
        unofficialEval();
        allInd.sort(new FitnessComparator());
    }

    public GATest(int n) {
        pop = new Population(n);
        allInd = pop.getPopulation();
        unofficialEval();
        allInd.sort(new FitnessComparator());
    }

    public GATest(int n, int mut) {
        pop = new Population(n);
        allInd = pop.getPopulation();
        mutation = mut;
        unofficialEval();
        allInd.sort(new FitnessComparator());
    }

    public GATest(int n, int mut, int cross) {
        pop = new Population(n);
        allInd = pop.getPopulation();
        mutation = mut;
        crossovers = cross;
        unofficialEval();
        allInd.sort(new FitnessComparator());
    }

    public GATest(int n, int mut, int cross, int max, String f) {
        pop = new Population(n);
        allInd = pop.getPopulation();
        mutation = mut;
        crossovers = cross;
        maxEvaluations = max;
        function = f;
        unofficialEval();
        allInd.sort(new FitnessComparator());
    }
    
    public GATest(int n, int mut, int cross, int max, String f, boolean hc) {
        pop = new Population(n);
        allInd = pop.getPopulation();
        mutation = mut;
        crossovers = cross;
        maxEvaluations = max;
        function = f;
        headlessChicken = hc;
        unofficialEval();
        allInd.sort(new FitnessComparator());
    }

    public void setFunction(String f) {
        function = f;
    }

    public void setMut(int mut) {
        this.mutation = mut;
    }

    public void setMax(int m) {
        this.maxEvaluations = m;
//        System.out.println("m = " + maxEvaluations);
    }

    public void setCross(int c) {
        this.crossovers = c;
    }

    public void go() {
        while (!done()) {
            doAGeneration();
        }
    }

    public boolean done() {
        return evaluations > maxEvaluations;
    }
    
    public boolean fit() {
        for (Evaluable next : allInd) {
            switch (function) {
                case "countOnes":
                    if (next.getFitness() == CountOnes.maxFitness()) {
                        return true;
                    }
                case "fitness4":
                    if (next.getFitness() == Fitness4.maxFitness()) {
                        return true;
                    }
                case "mystery":
                    if (next.getFitness() == Mystery.maxFitness()) {
                        return true;
                    }
                default:
                    if (next.getFitness() == CountOnes.maxFitness()) {
                        return true;
                    }
            }
        }
        return false;
    }

    public void doAGeneration() {
        evaluateFitness();
        selectMatingPool();
        applyGeneticOperators();
        replacement();
        unofficialEval();
        if (DEBUG) {
            System.out.println("" + evaluations);
        }
    }

    private void unofficialEval() {
        for (Evaluable next : allInd) {
            switch (function) {
                case "countOnes":
                    next.setFitness(CountOnes.getValue(next));
                    break;
                case "fitness4":
                    next.setFitness(Fitness4.getValue(next));
                    break;
                case "mystery":
                    next.setFitness(Mystery.getValue(next));
                    break;
                default:
                    next.setFitness(CountOnes.getValue(next));
            }
        }
    }

    private void evaluateFitness() {
//        System.out.println("evaluateFitness:stub");
        for (Evaluable next : allInd) {
            switch (function) {
                case "countOnes":
                    next.setFitness(CountOnes.getValue(next));
                    break;
                case "fitness4":
                    next.setFitness(Fitness4.getValue(next));
                    break;
                case "mystery":
                    next.setFitness(Mystery.getValue(next));
                    break;
                default:
                    next.setFitness(CountOnes.getValue(next));
            }
            evaluations++;
        }
        allInd.sort(new FitnessComparator());
    }

    private void selectMatingPool() {
//        System.out.println("selectMatingPool:stub");

        //simple top percentage selection
//        allInd.sort(new FitnessComparator());
//        int poolSize = (int) (allInd.size() * (matingPoolPercent / 100.0));
//        matingPool = new EvaluableList();
//        int index = 0;
//        while (matingPool.size() < poolSize) {
//            matingPool.add(allInd.get(index));
//            index++;
//        }
        //real selection
        int poolSize = (int) (allInd.size() * (matingPoolPercent / 100.0));
        matingPool = new EvaluableList();
        int sum = 0;
        for (Evaluable next : allInd) {
            sum += next.getFitness();
            next.setRunningSum(sum);
        }
        for (int p = 0; p < poolSize; p++) {
            int r = random(sum);
            int index = 0;
            while (allInd.get(index).getRunningSum() < r) {
                index++;
            }
            matingPool.add(allInd.get(index));
        }
        if (DEBUG) {
            System.out.println("MatingPool: " + matingPool.toString());
        }
    }

    private void applyGeneticOperators() {
//        System.out.println("applyGeneticOperators:stub");
        //simple cloning of fit ones
//        nextGen = new EvaluableList();
//        for (Evaluable next : matingPool) {
//            Evaluable e = next.myClone();
//            nextGen.add(e);
//        }

        //real genetic operators
        nextGen = new EvaluableList();
        performCrossover();
        performMutations();
        if (DEBUG) {
            System.out.println("NextGen: " + nextGen.toString());
        }
    }

    private void performCrossover() {
//        System.out.println("performCrossover:stub");
        if (headlessChicken) {
            headlessChicken();
        } else {
            normalCrossover();
        }
    }

    public void headlessChicken() {
        for (int i = 0; i < matingPool.size(); i++) {
            Evaluable e1 = matingPool.get(i).myClone();
            Evaluable e2 = new Individual();
            int c = 0;
            int chance = 100 / Evaluable.getLength();
            while (c < crossovers) {
                for (int j = 1; j < Evaluable.getLength(); j++) {
                    if (c < crossovers) {
                        if (random(100) < chance) {
                            if (DEBUG) {
                                System.out.println("cross at " + j);
                            }
                            for (int k = j; k < Evaluable.getLength(); k++) {
                                byte keepMe = e1.getDNA()[k];
                                e1.getDNA()[k] = e2.getDNA()[k];
                                e2.getDNA()[k] = keepMe;
                            }
                            c++;
                        }
                    }
                }
            }
            nextGen.add(e1);
        }
    }
    
    public void normalCrossover() {
        for (int i = 0; i < matingPool.size(); i = i + 2) {
            // create two clones of the parents
                Evaluable e1 = matingPool.get(i).myClone();
                Evaluable e2 = matingPool.get(i + 1).myClone();
                int c = 0; // how many crossovers it has done
                int chance = 100 / Evaluable.getLength(); // chance each bit has of being a crossover point
                while (c < crossovers) {
                    for (int j = 1; j < Evaluable.getLength(); j++) { // for all bits except the first
                        if (c < crossovers) {
                            if (random(100) < chance) { // if chosen as a crossover point
                                if (DEBUG) {
                                    System.out.println("cross at " + j);
                                }
                                // do crossover
                                for (int k = j; k < Evaluable.getLength(); k++) {
                                    byte keepMe = e1.getDNA()[k];
                                    e1.getDNA()[k] = e2.getDNA()[k];
                                    e2.getDNA()[k] = keepMe;
                                }
                                c++; // add to crossovers done
                            }
                        }
                    }
                }
                // add to next generation
                nextGen.add(e1);
                nextGen.add(e2);
            }
    }

    private void performMutations() {
//        System.out.println("performMutations:stub");
        for (Evaluable next : nextGen) {
            for (int i = 0; i < Evaluable.getLength(); i++) {
                if (random(1000) < mutation) {
                    if (DEBUG) {
//                    System.out.println("mutate");
                    }
                    toggle(next, i);
                }
            }
        }
    }

    public void toggle(Evaluable e, int i) {
        int v = e.getDNA()[i];
        if (v == 1) {
            e.getDNA()[i] = 0;
        } else {
            e.getDNA()[i] = 1;
        }
    }

    private void replacement() {
//        System.out.println("replacement:stub");
        allInd.sort(new FitnessComparator());
        for (int i = 1; i <= matingPool.size(); i++) {
            allInd.remove(allInd.size() - i);
            allInd.add(nextGen.get(0));
            nextGen.remove(0);
        }
    }

    public int random(int max) {
        return (int) (Math.random() * max);
    }

    @Override
    public String toString() {
        return pop.toString();
    }

    public double getResults(boolean avg) {
        if (avg) {
            return averageFitness();
        }
        return maxFitness();
    }

    private double averageFitness() {
        int sum = 0;
        int total = 0;
        for (Evaluable next : allInd) {
            sum += next.getFitness();
            total++;
        }
        return sum / ((double) total);
    }

    private double maxFitness() {
        allInd.sort(new FitnessComparator());
        return (double) (allInd.get(0).getFitness());
    }

}
