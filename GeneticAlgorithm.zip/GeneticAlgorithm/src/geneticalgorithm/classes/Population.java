package geneticalgorithm.classes;

import geneticalgorithm.fitnesses.Evaluable;
import geneticalgorithm.lists.EvaluableList;

public class Population {

    EvaluableList population;
    int popSize;

    public Population() {
        population = new EvaluableList();
        for (int i = 0; i < popSize; i++) {
            population.add(new Individual());
        }
    }
    
    public Population(int n) {
        popSize = n;
        population = new EvaluableList();
        for (int i = 0; i < popSize; i++) {
            population.add(new Individual());
        }
    }

    public void setSize(int s) {
        this.popSize = s;
    }

    public int getSize() {
        return popSize;
    }

    public EvaluableList getPopulation() {
        return population;
    }

    @Override
    public String toString() {
        String returnMe = "I am a Population:";
        returnMe += "\n\tPopulation Size = " + popSize;
        returnMe += "\n\tContaining:";
        for (Evaluable next : population) {
            returnMe += "\n\t\t" + next.toString();
        }
        return returnMe;
    }

    public static void main(String[] args) {
        Population p = new Population();
        System.out.println(p.toString());
    }

}
