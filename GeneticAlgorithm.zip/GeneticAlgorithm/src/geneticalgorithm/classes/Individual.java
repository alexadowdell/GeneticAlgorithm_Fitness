package geneticalgorithm.classes;

import geneticalgorithm.fitnesses.Evaluable;
import java.util.Arrays;

public class Individual implements Evaluable {

    protected byte[] DNA;
    protected int fitness;
    protected int runningSum;
    
    public Individual() {
        DNA = new byte[Evaluable.getLength()];
        for (int i = 0; i < Evaluable.getLength(); i++) {
            DNA[i] = (byte) (random(2));
        }
    }
    
    public Individual(byte[] DNA, int fitness) {
        this();
        this.DNA = DNA;
        this.fitness = fitness;
    }

    @Override
    public byte[] getDNA() {
        return DNA;
    }
    
    private byte[] copyDNA() {
        byte[] returnMe = new byte[Evaluable.getLength()];
        System.arraycopy(this.DNA, 0, returnMe, 0, Evaluable.getLength());
        return returnMe;
    }

    @Override
    public int getFitness() {
        return fitness;
    }
    
    @Override
    public int getRunningSum() {
        return runningSum;
    }

    public void setDNA(byte[] DNA) {
        this.DNA = DNA;
    }

    @Override
    public void setFitness(int fitness) {
        this.fitness = fitness;
    }
    
    @Override
    public void setRunningSum(int rs) {
        this.runningSum = rs;
    }

    @Override
    public Evaluable myClone() {
        Evaluable returnMe = new Individual(this.copyDNA(), this.getFitness());
        return returnMe;
    }

    @Override
    public String toString() {
        String returnMe = "I am an Individual:";
        returnMe += "\tFitness=" + getFitness();
        returnMe += "\tDNA=" + Arrays.toString(getDNA());
        return returnMe;
    }

    public int random(int max) {
        return (int) (Math.random() * max);
    }

    public static void main(String[] args) {
        Individual i = new Individual();
        System.out.println("i = " + i.toString());
        Individual j = (Individual) i.myClone();
        j.getDNA()[0] = 5;
        System.out.println("j = " + j.toString());
        System.out.println("i = " + i.toString());
    }

}
