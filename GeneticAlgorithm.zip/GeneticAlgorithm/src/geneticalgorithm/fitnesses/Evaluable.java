package geneticalgorithm.fitnesses;

public interface Evaluable {

    static int length = 100;
    
    static int getLength() {
        return length;
    }
    
    public byte[] getDNA();

    public int getFitness();

    public void setFitness(int fitness);

    public Evaluable myClone();
    
    public int getRunningSum();
    
    public void setRunningSum(int rs);
}
