package geneticalgorithm.fitnesses;

public class CountOnes {

    public static int getValue(Evaluable nextInd) {
        int count = 0;
        for (byte nextByte : nextInd.getDNA()) {
            if (nextByte == 1) {
                count++;
            }
        }
        return count;
    }
    
    public static int maxFitness() {
        return Evaluable.getLength();
    }
    
}
