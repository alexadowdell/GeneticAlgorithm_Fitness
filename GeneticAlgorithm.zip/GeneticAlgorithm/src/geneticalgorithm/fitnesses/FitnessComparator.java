package geneticalgorithm.fitnesses;

import java.util.Comparator;

public class FitnessComparator implements Comparator<Evaluable> {

    @Override
    public int compare(Evaluable e1, Evaluable e2) {
        if (e1.getFitness() < e2.getFitness()) {
            return 1;
        }
        if (e1.getFitness() > e2.getFitness()) {
            return -1;
        }
        return 0;
    }

}
