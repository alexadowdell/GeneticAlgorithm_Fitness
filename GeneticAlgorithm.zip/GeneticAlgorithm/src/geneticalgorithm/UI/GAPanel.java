package geneticalgorithm.UI;

import geneticalgorithm.classes.GATest;

public class GAPanel extends javax.swing.JPanel {

    GATest test;
    double[][] results;

    int n = 10;
    int mut = 100;
    int cross = 1;
    int max = 10000;
    String function = "countOnes";
    boolean headlessChicken = false;

    boolean average = true;

    public GAPanel() {
        initComponents();
        initButtons();
        test = new GATest(10, 100);
        results = new double[4][3];
    }

    private void initButtons() {
        functionGroup.add(countOnesButton);
        functionGroup.add(fitness4Button);
        functionGroup.add(mysteryButton);
        resultsGroup.add(maxButton);
        resultsGroup.add(avgButton);
    }

    public void output(String s) {
        theTA.append(s + "\n");
    }

    public String resultsString() {
        String returnMe = "" + max + " evaluations\n";
        returnMe += horiz() + "\n";
        for (int r = 0; r < 4; r++) {
            returnMe += format15(vert(r));
            for (int c = 0; c < 3; c++) {
                returnMe += format("| " + results[r][c]);
            }
            returnMe += "\n";
        }
        return returnMe;
    }

    private String horiz() {
        String returnMe = "";
        if (headlessChicken) {
            returnMe = format15("HC " + function);
        } else {
            returnMe = format15(function);
        }
        for (int c = 0; c < 3; c++) {
            returnMe += format("| Mutation rate = " + mutRate(c) / 1000.0);
        }
        returnMe += "\n____________________________________________________________________________________________";
        return returnMe;
    }

    private String vert(int r) {
        String returnMe = "";
        returnMe += "n = " + popSize(r);
        return returnMe;
    }

    public String format15(String s) {
        String returnMe = s;
        while (returnMe.length() < 15) {
            returnMe += " ";
        }
        return returnMe;
    }

    public String format(String s) {
        String returnMe = s;
        while (returnMe.length() < 28) {
            returnMe += " ";
        }
        return returnMe;
    }

    public int popSize(int r) {
        return pow(10, r + 1);
    }

    public int pow(int b, int p) {
        int returnMe = 1;
        for (int i = 0; i < p; i++) {
            returnMe *= b;
        }
        return returnMe;
    }

    public int mutRate(int c) {
        return pow(10, c);
    }

    public void reset() {
        test = new GATest(10, mut, cross, max, function, headlessChicken);
        results = new double[4][3];
    }

    public void clear() {
        theTA.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        functionGroup = new javax.swing.ButtonGroup();
        resultsGroup = new javax.swing.ButtonGroup();
        generationButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        theTA = new javax.swing.JTextArea();
        resultsButton = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();
        crossSlider = new javax.swing.JSlider();
        jLabel1 = new javax.swing.JLabel();
        countOnesButton = new javax.swing.JRadioButton();
        fitness4Button = new javax.swing.JRadioButton();
        mysteryButton = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        maxSlider = new javax.swing.JSlider();
        jLabel3 = new javax.swing.JLabel();
        mutSlider = new javax.swing.JSlider();
        jLabel4 = new javax.swing.JLabel();
        maxTF = new javax.swing.JTextField();
        mutTF = new javax.swing.JTextField();
        maxButton = new javax.swing.JRadioButton();
        avgButton = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        hcButton = new javax.swing.JToggleButton();
        clearButton = new javax.swing.JButton();
        findOptimalButton = new javax.swing.JButton();

        setBackground(new java.awt.Color(204, 204, 204));

        generationButton.setBackground(new java.awt.Color(204, 255, 204));
        generationButton.setText("Do A Generation");
        generationButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generationButtonActionPerformed(evt);
            }
        });

        theTA.setEditable(false);
        theTA.setColumns(20);
        theTA.setFont(new java.awt.Font("Courier", 0, 13)); // NOI18N
        theTA.setRows(5);
        jScrollPane1.setViewportView(theTA);

        resultsButton.setText("Get Results");
        resultsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resultsButtonActionPerformed(evt);
            }
        });

        resetButton.setText("Reset");
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        crossSlider.setMajorTickSpacing(1);
        crossSlider.setMaximum(4);
        crossSlider.setMinorTickSpacing(1);
        crossSlider.setPaintLabels(true);
        crossSlider.setPaintTicks(true);
        crossSlider.setSnapToTicks(true);
        crossSlider.setValue(1);
        crossSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                crossSliderStateChanged(evt);
            }
        });

        jLabel1.setText("Crossovers:");

        countOnesButton.setSelected(true);
        countOnesButton.setText("CountOnes");
        countOnesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countOnesButtonActionPerformed(evt);
            }
        });

        fitness4Button.setText("Fitness4");
        fitness4Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fitness4ButtonActionPerformed(evt);
            }
        });

        mysteryButton.setText("Mystery");
        mysteryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mysteryButtonActionPerformed(evt);
            }
        });

        jLabel2.setLabelFor(countOnesButton);
        jLabel2.setText("Fitness Functions:");

        maxSlider.setMinimum(1);
        maxSlider.setValue(1);
        maxSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                maxSliderStateChanged(evt);
            }
        });

        jLabel3.setText("Maximum Evaluations:");

        mutSlider.setMaximum(1000);
        mutSlider.setValue(100);
        mutSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                mutSliderStateChanged(evt);
            }
        });

        jLabel4.setText("Mutation Rate:");

        maxTF.setEditable(false);
        maxTF.setText("10000 evaluations");

        mutTF.setEditable(false);
        mutTF.setText("10.0%");

        maxButton.setText("Maximum");
        maxButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maxButtonActionPerformed(evt);
            }
        });

        avgButton.setSelected(true);
        avgButton.setText("Average");
        avgButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                avgButtonActionPerformed(evt);
            }
        });

        jLabel5.setText("Results Type:");

        hcButton.setText("Headless Chicken Off");
        hcButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hcButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        findOptimalButton.setText("Find Optimal Fitness");
        findOptimalButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findOptimalButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 449, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(resetButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(clearButton))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(135, 135, 135))
                    .addComponent(hcButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(crossSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2)
                    .addComponent(countOnesButton)
                    .addComponent(fitness4Button)
                    .addComponent(mysteryButton)
                    .addComponent(jLabel3)
                    .addComponent(maxSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(maxTF)
                    .addComponent(jLabel4)
                    .addComponent(mutTF)
                    .addComponent(mutSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(generationButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5)
                    .addComponent(avgButton)
                    .addComponent(maxButton)
                    .addComponent(resultsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(findOptimalButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(crossSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(countOnesButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fitness4Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mysteryButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(maxSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(maxTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mutSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mutTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(avgButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(maxButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hcButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                        .addComponent(generationButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(findOptimalButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(resultsButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(resetButton)
                            .addComponent(clearButton)))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void generationButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generationButtonActionPerformed
        output("Before: " + test.toString());
        test.doAGeneration();
        output("After: " + test.toString());
        output("\n");
    }//GEN-LAST:event_generationButtonActionPerformed

    private void resultsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resultsButtonActionPerformed
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 3; c++) {
                test = new GATest(popSize(r), mutRate(c), cross, max, function, headlessChicken);
                test.go();
                results[r][c] = test.getResults(average);
            }
        }
        output(resultsString());
    }//GEN-LAST:event_resultsButtonActionPerformed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        reset();
    }//GEN-LAST:event_resetButtonActionPerformed

    private void crossSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_crossSliderStateChanged
        cross = crossSlider.getValue();
        test.setCross(cross);
    }//GEN-LAST:event_crossSliderStateChanged

    private void countOnesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countOnesButtonActionPerformed
        if (countOnesButton.isSelected()) {
            function = "countOnes";
        }
        reset();
    }//GEN-LAST:event_countOnesButtonActionPerformed

    private void fitness4ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fitness4ButtonActionPerformed
        if (fitness4Button.isSelected()) {
            function = "fitness4";
        }
        reset();
    }//GEN-LAST:event_fitness4ButtonActionPerformed

    private void mysteryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mysteryButtonActionPerformed
        if (mysteryButton.isSelected()) {
            function = "mystery";
        }
        reset();
    }//GEN-LAST:event_mysteryButtonActionPerformed

    private void maxSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_maxSliderStateChanged
        max = maxSlider.getValue() * 10000;
        maxTF.setText("" + max + " evaluations");
        reset();
    }//GEN-LAST:event_maxSliderStateChanged

    private void mutSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_mutSliderStateChanged
        mut = mutSlider.getValue();
        test.setMut(mutSlider.getValue());
        mutTF.setText("" + mut / 10.0 + "%");
    }//GEN-LAST:event_mutSliderStateChanged

    private void maxButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maxButtonActionPerformed
        if (maxButton.isSelected()) {
            average = false;
        }
        reset();
    }//GEN-LAST:event_maxButtonActionPerformed

    private void avgButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_avgButtonActionPerformed
        if (avgButton.isSelected()) {
            average = true;
        }
        reset();
    }//GEN-LAST:event_avgButtonActionPerformed

    private void hcButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hcButtonActionPerformed
        headlessChicken = !headlessChicken;
        if (headlessChicken) {
            hcButton.setText("Headless Chicken On");
        } else {
            hcButton.setText("Headless Chicken Off");
        }
    }//GEN-LAST:event_hcButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clear();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void findOptimalButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findOptimalButtonActionPerformed
        output("Before: " + test.toString());
        int gens = 0;
        while (!test.fit()) {
            test.doAGeneration();
            gens++;
        }
        output("After " + gens + " generations: " + test.toString());
        output("\n");
    }//GEN-LAST:event_findOptimalButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton avgButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JRadioButton countOnesButton;
    private javax.swing.JSlider crossSlider;
    private javax.swing.JButton findOptimalButton;
    private javax.swing.JRadioButton fitness4Button;
    private javax.swing.ButtonGroup functionGroup;
    private javax.swing.JButton generationButton;
    private javax.swing.JToggleButton hcButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton maxButton;
    private javax.swing.JSlider maxSlider;
    private javax.swing.JTextField maxTF;
    private javax.swing.JSlider mutSlider;
    private javax.swing.JTextField mutTF;
    private javax.swing.JRadioButton mysteryButton;
    private javax.swing.JButton resetButton;
    private javax.swing.JButton resultsButton;
    private javax.swing.ButtonGroup resultsGroup;
    private javax.swing.JTextArea theTA;
    // End of variables declaration//GEN-END:variables

}
