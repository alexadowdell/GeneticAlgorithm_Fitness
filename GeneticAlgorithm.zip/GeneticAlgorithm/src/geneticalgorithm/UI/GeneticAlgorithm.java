package geneticalgorithm.UI;

import geneticalgorithm.UI.GAFrame;

public class GeneticAlgorithm {

    public static void main(String[] args) {
        new GAFrame();
    }

}
