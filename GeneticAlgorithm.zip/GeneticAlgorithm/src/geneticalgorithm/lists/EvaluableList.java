package geneticalgorithm.lists;

import geneticalgorithm.fitnesses.Evaluable;
import java.util.ArrayList;

public class EvaluableList extends ArrayList<Evaluable>{

    @Override
    public String toString() {
        String returnMe = "I am an EvaluableList:";
        returnMe += "\n\tContaining:";
        for (Evaluable next : this) {
            returnMe += "\n\t\t" + next.toString();
        }
        return returnMe;
    }
    
}
